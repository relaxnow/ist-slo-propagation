<?php
/**
 * SAML 1.1 SP configuration for simpleSAMLphp.
 *
 * See: https://rnd.feide.no/content/sp-hosted-metadata-reference
 */

/*
 * Example of hosted Shibboleth 1.3 SP.
 */
$metadata['__DYNAMIC:1__'] = array(
	'host' => '__DEFAULT__',
);
